#include "ExampleConnection.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void serviceMessageLoop(){
    eLeapRS result;
    LEAP_CONNECTION_MESSAGE msg;
    while(_isRunning){
        unsigned int timeout = 1000;
        result = LeapPollConnection(connectionHandle, timeout, &msg);
        //Handle message
    }
}